import express from "express";
import {
  createSeller,
  getAllSellers,
  getCurrentSellerProfile,
  deleteSellerById,
  getSellerById,
} from "../controllers/sellerController.js";

import { authenticate, authorizeAdmin } from "../middlewares/authMiddleware.js";

const router = express.Router();
router
  .route("/")
  .post(createSeller)
  .get(authenticate, authorizeAdmin, getAllSellers);

router.route("/profile").get(authenticate, getCurrentSellerProfile);

// ADMIN ROUTES 👇
router
  .route("/:id")
  .delete(authenticate, authorizeAdmin, deleteSellerById)
  .get(authenticate, authorizeAdmin, getSellerById);

export default router;

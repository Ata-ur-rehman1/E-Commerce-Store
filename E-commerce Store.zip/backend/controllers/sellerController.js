import Seller from "../models/sellerModel.js";
import asyncHandler from "../middlewares/asyncHandler.js";

const createSeller = asyncHandler(async (req, res) => {
  const {
    cnicorPassport,
    postalCode,
    address,
    debiteCard,
    expireDate,
    code,
    addressCard,
  } = req.body;

  if (
    !cnicorPassport ||
    !postalCode ||
    !address ||
    !debiteCard ||
    !expireDate ||
    !code ||
    !addressCard
  ) {
    throw new Error("Please fill all the inputs.");
  }
  const sellerExists = await Seller.findOne({
    cnicorPassport,
    debiteCard,
  });
  if (sellerExists) res.status(400).send("User already exists");
  // Here hashedPassword is a property of password.
  const newSeller = new User({
    cnicorPassport,
    postalCode,
    address,
    debiteCard,
    expireDate,
    code,
    addressCard,
  });
  try {
    // Here user's username, email, and password are saving in the mongodb DATABASE.
    await newSeller.save();
    createToken(res, newSeller._id);
    // This below code is written to check Seller's data in the postman body pretty which provided.
    res.status(201).json({
      _id: newSeller._id,
      cnicorPassport: newSeller.cnicorPassport,
      postalCode: newSeller.postalCode,
      address: newSeller.addressCard,
      debiteCard: newSeller.debiteCard,
      expireDate: newSeller.expireDate,
      code: newSeller.code,
      addressCard: newSeller.addressCard,
    });
  } catch (error) {
    res.status(400);
    throw new Error("Invalid seller data");
  }
});

const getAllSeller = asyncHandler(async (req, res) => {
  const sellers = await Seller.find({});
  res.json(sellers);
});

const getCurrentUserProfile = asyncHandler(async (req, res) => {
  const seller = await Seller.findById(req.seller._id);

  if (seller) {
    res.json({
      _id: seller._id,
      username: seller.username,
      email: seller.email,
    });
  } else {
    res.status(404);
    throw new Error("User not found.");
  }
});

const deleteSellerById = asyncHandler(async (req, res) => {
  const seller = await Seller.findById(req.params.id);

  if (seller) {
    if (seller.isAdmin) {
      res.status(400);
      throw new Error("Cannot delete admin user");
    }

    await Seller.deleteOne({ _id: seller._id });
    res.json({ message: "User removed" });
  } else {
    res.status(404);
    throw new Error("User not found.");
  }
});

const getUserById = asyncHandler(async (req, res) => {
  const seller = await Seller.findById(req.params.id).select("-password");

  if (seller) {
    res.json(user);
  } else {
    res.status(404);
    throw new Error("User not found");
  }
});

export {
  createSeller,
  getAllSeller,
  getCurrentUserProfile,
  deleteSellerById,
  getUserById,
};

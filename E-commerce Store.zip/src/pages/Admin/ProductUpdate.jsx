import { useState, useEffect } from "react";
import AdminMenu from "./AdminMenu";
import { useNavigate, useParams } from "react-router-dom";
import {
  useUpdateProductMutation,
  useDeleteProductMutation,
  useGetProductByIdQuery,
  useUploadProductImageMutation,
} from "../../redux/api/productApiSlice";
import { useFetchCategoriesQuery } from "../../redux/api/categoryApiSlice";
import { toast } from "react-toastify";

const AdminProductUpdate = () => {
  const params = useParams();

  const { data: productData } = useGetProductByIdQuery(params._id);

  console.log(productData);

  const [image, setImage] = useState(productData?.image || "");
  const [name, setName] = useState(productData?.name || "");
  const [description, setDescription] = useState(
    productData?.description || ""
  );

  // Description Deatils.
  const [description2, setDescription2] = useState(
    productData?.description2 || ""
  );
  const [description3, setDescription3] = useState(
    productData?.description3 || ""
  );
  const [description4, setDescription4] = useState(
    productData?.description4 || ""
  );
  const [description5, setDescription5] = useState(
    productData?.description5 || ""
  );
  const [description6, setDescription6] = useState(
    productData?.description6 || ""
  );
  const [description7, setDescription7] = useState(
    productData?.description7 || ""
  );
  const [description8, setDescription8] = useState(
    productData?.description8 || ""
  );
  const [description9, setDescription9] = useState(
    productData?.description9 || ""
  );
  const [description10, setDescription10] = useState(
    productData?.description10 || ""
  );
  const [description11, setDescription11] = useState(
    productData?.description11 || ""
  );
  const [description12, setDescription12] = useState(
    productData?.description12 || ""
  );
  const [description13, setDescription13] = useState(
    productData?.description13 || ""
  );
  const [description14, setDescription14] = useState(
    productData?.description14 || ""
  );
  // Description Details Name.

  const [pdName2, setpdName2] = useState(productData?.pdName3 || "");
  const [pdName3, setpdName3] = useState(productData?.pdName3 || "");
  const [pdName4, setpdName4] = useState(productData?.pdName4 || "");
  const [pdName5, setpdName5] = useState(productData?.pdName5 || "");
  const [pdName6, setpdName6] = useState(productData?.pdName6 || "");
  const [pdName7, setpdName7] = useState(productData?.pdName7 || "");
  const [pdName8, setpdName8] = useState(productData?.pdName8 || "");
  const [pdName9, setpdName9] = useState(productData?.pdName9 || "");
  const [pdName10, setpdName10] = useState(productData?.pdName10 || "");
  const [pdName11, setpdName11] = useState(productData?.pdName11 || "");
  const [pdName12, setpdName12] = useState(productData?.pdName12 || "");
  const [pdName13, setpdName13] = useState(productData?.pdName13 || "");
  const [pdName14, setpdName14] = useState(productData?.pdName14 || "");

  const [price, setPrice] = useState(productData?.price || "");
  const [category, setCategory] = useState(productData?.category || "");
  const [quantity, setQuantity] = useState(productData?.quantity || "");
  const [brand, setBrand] = useState(productData?.brand || "");
  const [stock, setStock] = useState(productData?.countInStock);

  // hook
  const navigate = useNavigate();

  // Fetch categories using RTK Query
  const { data: categories = [] } = useFetchCategoriesQuery();

  const [uploadProductImage] = useUploadProductImageMutation();

  // Define the update product mutation
  const [updateProduct] = useUpdateProductMutation();

  // Define the delete product mutation
  const [deleteProduct] = useDeleteProductMutation();

  useEffect(() => {
    if (productData && productData._id) {
      setName(productData.name);
      setDescription(productData.description);
      // Description Details.
      setDescription2(productData.description2);
      setDescription3(productData.description3);
      setDescription4(productData.description4);
      setDescription5(productData.description5);
      setDescription6(productData.description6);
      setDescription7(productData.description7);
      setDescription8(productData.description8);
      setDescription9(productData.description9);
      setDescription10(productData.description10);
      setDescription11(productData.description11);
      setDescription12(productData.description12);
      setDescription13(productData.description13);
      setDescription14(productData.description14);
      // Description Details Name.
      setpdName2(productData.pdName2);
      setpdName3(productData.pdName3);
      setpdName4(productData.pdName4);
      setpdName5(productData.pdName5);
      setpdName6(productData.pdName6);
      setpdName7(productData.pdName7);
      setpdName8(productData.pdName8);
      setpdName9(productData.pdName9);
      setpdName10(productData.pdName10);
      setpdName11(productData.pdName11);
      setpdName12(productData.pdName12);
      setpdName13(productData.pdName13);
      setpdName14(productData.pdName14);
      setPrice(productData.price);
      setCategory(productData.category?._id);
      setQuantity(productData.quantity);
      setBrand(productData.brand);
      setImage(productData.image);
    }
  }, [productData]);

  const uploadFileHandler = async (e) => {
    const formData = new FormData();
    formData.append("image", e.target.files[0]);
    try {
      const res = await uploadProductImage(formData).unwrap();
      toast.success("Item added successfully", {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
      setImage(res.image);
    } catch (err) {
      toast.success("Item added successfully", {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("image", image);
      formData.append("name", name);
      formData.append("description", description);
      // Product Description Details.
      formData.append("description2", description2);
      formData.append("description3", description3);
      formData.append("description4", description4);
      formData.append("description5", description5);
      formData.append("description6", description6);
      formData.append("description7", description7);
      formData.append("description8", description8);
      formData.append("description9", description9);
      formData.append("description10", description10);
      formData.append("description11", description11);
      formData.append("description12", description12);
      formData.append("description13", description13);
      formData.append("description14", description14);
      // Product Description Details Name.
      formData.append("pdName2", pdName2);
      formData.append("pdName3", pdName3);
      formData.append("pdName4", pdName4);
      formData.append("pdName5", pdName5);
      formData.append("pdName6", pdName6);
      formData.append("pdName7", pdName7);
      formData.append("pdName8", pdName8);
      formData.append("pdName9", pdName9);
      formData.append("pdName10", pdName10);
      formData.append("pdName11", pdName11);
      formData.append("pdName12", pdName12);
      formData.append("pdName13", pdName13);
      formData.append("pdName14", pdName14);

      formData.append("price", price);
      formData.append("category", category);
      formData.append("quantity", quantity);
      formData.append("brand", brand);
      formData.append("countInStock", stock);

      // Update product using the RTK Query mutation
      const { data } = await updateProduct({ productId: params._id, formData });

      if (data.error) {
        toast.error(data.error, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 2000,
        });
      } else {
        toast.success(`Product successfully updated`, {
          position: toast.POSITION.TOP_RIGHT,
          autoClose: 2000,
        });
        navigate("/admin/allproductslist");
      }
    } catch (err) {
      console.log(err);
      toast.error("Product update failed. Try again.", {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
    }
  };

  const handleDelete = async () => {
    try {
      let answer = window.confirm(
        "Are you sure you want to delete this product?"
      );
      if (!answer) return;

      const { data } = await deleteProduct(params._id);
      toast.success(`"${data.name}" is deleted`, {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
      navigate("/admin/allproductslist");
    } catch (err) {
      console.log(err);
      toast.error("Delete failed. Try again.", {
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 2000,
      });
    }
  };

  return (
    <>
      <div className="container  xl:mx-[9rem] sm:mx-[0]">
        <div className="flex flex-col md:flex-row">
          <AdminMenu />
          <div className="md:w-3/4 p-3">
            <div className="h-12">Update / Delete Product</div>

            {image && (
              <div className="text-center">
                <img
                  src={image}
                  alt="product"
                  className="block mx-auto w-full h-[40%]"
                />
              </div>
            )}

            <div className="mb-3">
              <label className="text-white py-2 px-4 block w-full text-center rounded-lg cursor-pointer font-bold py-11">
                {image ? image.name : "Upload image"}
                <input
                  type="file"
                  name="image"
                  accept="image/*"
                  onChange={uploadFileHandler}
                  className="input-container-three text-white"
                />
              </label>
            </div>

            <div className="p-3">
              <div className="flex flex-wrap">
                <div className="one">
                  <label htmlFor="name">Name</label> <br />
                  <input
                    type="text"
                    className="input-container-two p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white mr-[5rem]"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div className="two">
                  <label htmlFor="name block">Price</label> <br />
                  <input
                    type="number"
                    className="input-container-two p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white "
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-wrap">
                <div>
                  <label htmlFor="name block">Quantity</label> <br />
                  <input
                    type="number"
                    min="1"
                    className="input-container-two p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white mr-[5rem]"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                </div>
                <div>
                  <label htmlFor="name block">Brand</label> <br />
                  <input
                    type="text"
                    className="input-container-two p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white "
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                  />
                </div>
              </div>
              <label htmlFor="" className="my-5">
                Description
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
              {/* Product Description Name and Details. */}
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName2}
                onChange={(e) => setpdName2(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description2}
                onChange={(e) => setDescription2(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName3}
                onChange={(e) => setpdName3(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description3}
                onChange={(e) => setDescription3(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName4}
                onChange={(e) => setpdName4(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description4}
                onChange={(e) => setDescription4(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName5}
                onChange={(e) => setpdName5(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description5}
                onChange={(e) => setDescription5(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName6}
                onChange={(e) => setpdName6(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description7}
                onChange={(e) => setDescription7(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName8}
                onChange={(e) => setpdName8(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description8}
                onChange={(e) => setDescription8(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName9}
                onChange={(e) => setpdName9(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description9}
                onChange={(e) => setDescription9(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName10}
                onChange={(e) => setpdName10(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description10}
                onChange={(e) => setDescription10(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName11}
                onChange={(e) => setpdName11(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description11}
                onChange={(e) => setDescription11(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName12}
                onChange={(e) => setpdName12(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description12}
                onChange={(e) => setDescription12(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Name Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={pdName13}
                onChange={(e) => setpdName13(e.target.value)}
              />
              <br />
              <label htmlFor="" className="my-5">
                Input Description Details{" "}
              </label>
              <textarea
                type="text"
                className="p-2 mb-3 bg-[#101011]  border rounded-lg w-[95%] text-white"
                value={description14}
                onChange={(e) => setDescription14(e.target.value)}
              />
              <div className="flex justify-between">
                <div>
                  <label htmlFor="name block">Count In Stock</label> <br />
                  <input
                    type="text"
                    className="input-container-two p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white "
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                  />
                </div>

                <div>
                  <label htmlFor="">Category</label> <br />
                  <select
                    placeholder="Choose Category"
                    className="p-4 mb-3 w-[30rem] border rounded-lg bg-[#101011] text-white mr-[5rem]"
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    {categories?.map((c) => (
                      <option key={c._id} value={c._id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="">
                <button
                  onClick={handleSubmit}
                  className="py-4 px-10 mt-5 rounded-lg text-lg font-bold  bg-green-600 mr-6"
                >
                  Update
                </button>
                <button
                  onClick={handleDelete}
                  className="py-4 px-10 mt-5 rounded-lg text-lg font-bold  bg-pink-600"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminProductUpdate;

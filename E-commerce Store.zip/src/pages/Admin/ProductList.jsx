// import "./ProductLists.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useCreateProductMutation,
  useUploadProductImageMutation,
} from "../../redux/api/productApiSlice";
import { useFetchCategoriesQuery } from "../../redux/api/categoryApiSlice";
import { toast } from "react-toastify";
import AdminMenu from "./AdminMenu";

const ProductList = () => {
  const [image, setImage] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pdName2, setPdName2] = useState("");
  const [description2, setDescription2] = useState("");
  const [pdName3, setPdName3] = useState("");
  const [description3, setDescription3] = useState("");
  const [pdName4, setPdName4] = useState("");
  const [description4, setDescription4] = useState("");
  const [pdName5, setPdName5] = useState("");
  const [description5, setDescription5] = useState("");
  const [pdName6, setPdName6] = useState("");
  const [description6, setDescription6] = useState("");
  const [pdName7, setPdName7] = useState("");
  const [description7, setDescription7] = useState("");
  const [pdName8, setPdName8] = useState("");
  const [description8, setDescription8] = useState("");
  const [pdName9, setPdName9] = useState("");
  const [description9, setDescription9] = useState("");
  const [pdName10, setPdName10] = useState("");
  const [description10, setDescription10] = useState("");
  const [pdName11, setPdName11] = useState("");
  const [description11, setDescription11] = useState("");
  const [pdName12, setPdName12] = useState("");
  const [description12, setDescription12] = useState("");
  const [pdName13, setPdName13] = useState("");
  const [description13, setDescription13] = useState("");
  const [pdName14, setPdName14] = useState("");
  const [description14, setDescription14] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [quantity, setQuantity] = useState("");
  const [brand, setBrand] = useState("");
  const [stock, setStock] = useState(0);
  const [imageUrl, setImageUrl] = useState(null);
  const navigate = useNavigate();

  const [uploadProductImage] = useUploadProductImageMutation();
  const [createProduct] = useCreateProductMutation();
  const { data: categories } = useFetchCategoriesQuery();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const productData = new FormData();
      productData.append("image", image);
      productData.append("name", name);
      // Product Detials names.
      productData.append("pdName2", pdName2);
      productData.append("pdName3", pdName3);
      productData.append("pdName4", pdName4);
      productData.append("pdName5", pdName5);
      productData.append("pdName6", pdName6);
      productData.append("pdName7", pdName7);
      productData.append("pdName8", pdName8);
      productData.append("pdName9", pdName9);
      productData.append("pdName10", pdName10);
      productData.append("pdName11", pdName11);
      productData.append("pdName12", pdName12);
      productData.append("pdName13", pdName13);
      productData.append("pdName14", pdName14);
      // Description.
      productData.append("description", description);
      productData.append("description2", description2);
      productData.append("description3", description3);
      productData.append("description4", description4);
      productData.append("description5", description5);
      productData.append("description6", description6);
      productData.append("description7", description7);
      productData.append("description8", description8);
      productData.append("description9", description9);
      productData.append("description10", description10);
      productData.append("description11", description11);
      productData.append("description12", description12);
      productData.append("description13", description13);
      productData.append("description14", description14);
      productData.append("price", price);
      productData.append("category", category);
      productData.append("quantity", quantity);
      productData.append("brand", brand);
      productData.append("countInStock", stock);
      const { data } = await createProduct(productData);

      if (data?.error) {
        toast.error("Product create failed. Try Again.");
      } else {
        toast.success(`${data.name} is created`);
        navigate("/");
      }
    } catch (error) {
      console.error(error);
      toast.error("Product create failed. Try Again.");
    }
  };

  const uploadFileHandler = async (e) => {
    const formData = new FormData();
    formData.append("image", e.target.files[0]);

    try {
      const res = await uploadProductImage(formData).unwrap();
      toast.success(res.message);
      setImage(res.image);
      setImageUrl(res.image);
    } catch (error) {
      toast.error(error?.data?.message || error.error);
    }
  };

  return (
    <div className="container xl:mx-[9rem] sm:mx-[0] pl-[200px]">
      <div className="flex flex-col md:flex-row">
        <AdminMenu />
        <div className="md:w-3/4 p-3">
          <div className="h-12">Create Product</div>

          {imageUrl && (
            <div className="text-center ml-[15rem]">
              <img
                src={imageUrl}
                alt="product"
                className="block mx-auto max-h-[600px] w-[24rem]"
              />
            </div>
          )}

          <div className="mb-3 w-[54rem]">
            <label className="border text-white px-4 block w-full text-center rounded-lg cursor-pointer font-bold py-11">
              {image ? image.name : "Upload Image"}

              <input
                type="file"
                name="image"
                accept="image/*"
                onChange={uploadFileHandler}
                className={!image ? "hidden" : "text-white"}
              />
            </label>
          </div>

          <div className="p-3">
            <div className="flex pl-7">
              <div className="">
                <label htmlFor="" className="my-5">
                  Name
                </label>
                <br />
                <input
                  type="text"
                  className="w-[20rem] h-[3rem] bg-[#101011] border rounded-lg  text-white"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="pl-6">
                <label htmlFor="" className="my-5">
                  Price
                </label>
                <br />
                <input
                  type="number"
                  className="w-[20rem] h-[3rem] bg-[#101011] border rounded-lg  text-white"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </div>
            </div>
            <br />{" "}
            <div className="flex pl-7">
              <div className="">
                <label htmlFor="" className="my-5">
                  Quantity
                </label>
                <br />
                <input
                  type="number"
                  className="w-[20rem] h-[3rem] bg-[#101011] border rounded-lg  text-white"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
              </div>
              <div className="pl-6">
                <label htmlFor="" className="">
                  Brand
                </label>
                <br />
                <input
                  type="text"
                  className="w-[20rem] h-[3rem] bg-[#101011] border rounded-lg  text-white"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                />
              </div>
            </div>
            <br />
            <label htmlFor="" className="my-5">
              Description
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <br></br>
             <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName2}
              onChange={(e) => setPdName2(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description2}
              onChange={(e) => setDescription2(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName3}
              onChange={(e) => setPdName3(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description3}
              onChange={(e) => setDescription3(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName4}
              onChange={(e) => setPdName4(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description4}
              onChange={(e) => setDescription4(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName5}
              onChange={(e) => setPdName5(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description5}
              onChange={(e) => setDescription5(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName6}
              onChange={(e) => setPdName6(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description6}
              onChange={(e) => setDescription6(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName7}
              onChange={(e) => setPdName7(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description7}
              onChange={(e) => setDescription7(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName8}
              onChange={(e) => setPdName8(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description8}
              onChange={(e) => setDescription8(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName9}
              onChange={(e) => setPdName9(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description9}
              onChange={(e) => setDescription9(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName10}
              onChange={(e) => setPdName10(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description10}
              onChange={(e) => setDescription10(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName11}
              onChange={(e) => setPdName11(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description11}
              onChange={(e) => setDescription11(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName12}
              onChange={(e) => setPdName12(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description12}
              onChange={(e) => setDescription12(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName13}
              onChange={(e) => setPdName13(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description13}
              onChange={(e) => setDescription13(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={pdName14}
              onChange={(e) => setPdName14(e.target.value)}
            ></textarea>
            <br></br>
            <label htmlFor="" className="my-5">
              Write the Description Input Name Details
            </label>
            <textarea
              type="text"
              className="p-2 mb-3 bg-[#101011] border rounded-lg w-[50rem] text-white"
              value={description14}
              onChange={(e) => setDescription14(e.target.value)}
            ></textarea> 
            <div className="flex justify-between">
               <div>
                <label htmlFor="name block" className="ml-[40px]">Count In Stock</label>
                 <br />
                <input
                  type="text"
                  className="p-4 mb-3 ml-[40px] w-[20rem] border rounded-lg bg-[#101011] text-white"
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                />
              </div>
              <br/>
                <div>
                <label htmlFor="" className="ml-[80px]">Category</label> <br />
                <select
                  placeholder="Choose Category"
                  className="p-4 ml-[80px] w-[20rem] border rounded-lg bg-[#101011] text-white"
                  onChange={(e) => setCategory(e.target.value)}
                >
                  {categories?.map((c) => (
                    <option key={c._id} value={c._id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              onClick={handleSubmit}
              className="py-4 px-10 mt-5 rounded-lg text-lg font-bold bg-pink-600"
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductList;

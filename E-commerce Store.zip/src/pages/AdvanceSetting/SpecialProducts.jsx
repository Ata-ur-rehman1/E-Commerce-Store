const specialProducts = () => {
  return (
    <>
      <div style={{ color: "red" }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam,
        facilis porro provident doloremque praesentium ipsam amet libero
        delectus nisi a quia repudiandae beatae laborum, saepe ut quos, eum
        incidunt aliquid.
      </div>
    </>
  );
};
export default specialProducts;

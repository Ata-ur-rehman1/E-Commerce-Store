const GiftCards = () => {
  return (
    <>
      <h1>GiftCards</h1>
    </>
  );
};
export default GiftCards;

// import ReactImageMagnify from "react-image-magnify";
import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
// import "./productDetails.css";
import {
  useGetProductDetailsQuery,
  useCreateReviewMutation,
} from "../../redux/api/productApiSlice";
import Loader from "../../components/Loader";
import Message from "../../components/Message";
import {
  FaBox,
  FaClock,
  FaShoppingCart,
  FaStar,
  FaStore,
} from "react-icons/fa";
import moment from "moment";
import HeartIcon from "./HeartIcon";
import Ratings from "./Ratings";
import ProductTabs from "./ProductTabs";
import { addToCart } from "../../redux/features/cart/cartSlice";

const ProductDetails = () => {
  const { id: productId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { products } = useSelector((state) => state.shop);

  const [qty, setQty] = useState(1);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const {
    data: product,
    isLoading,
    refetch,
    error,
  } = useGetProductDetailsQuery(productId);

  const { userInfo } = useSelector((state) => state.auth);

  const [createReview, { isLoading: loadingProductReview }] =
    useCreateReviewMutation();

  const submitHandler = async (e) => {
    e.preventDefault();

    try {
      await createReview({
        productId,
        rating,
        comment,
      }).unwrap();
      refetch();
      toast.success("Review created successfully");
    } catch (error) {
      toast.error(error?.data || error.message);
    }
  };

  const addToCartHandler = () => {
    dispatch(addToCart({ ...product, qty }));
    navigate("/cart");
  };

  return (
    <>
      <div>
        <Link
          to="/"
          className="text-white font-semibold hover:underline ml-[10rem]"
        >
          Go Back
        </Link>
      </div>
      {isLoading ? (
        <Loader />
      ) : error ? (
        <Message variant="danger">
          {error?.data?.message || error.message}
        </Message>
      ) : (
        <>
          <div className="flex flex-wrap items-between mt-[2rem] ml-[10rem]">
            <div>
              <div className="absolute">
                <div
                  style={{
                    height: "170px",
                    width: "500px",
                    backgroundImage: "cover",
                  }}
                >
                  <img src={product.image} alt={product.name} />
                  {/* <ReactImageMagnify
                    {...{
                      smallImage: {
                        alt: "Wristwatch by Ted Baker London",
                        isFluidWidth: true,
                        sizes:
                          "(max-width: 780px) 100vw, (max-width: 1200px) 100vw, 360px",
                        src: product.image,
                        alt: product.name,
                      },
                      largeImage: {
                        src: product.image,
                        width: 600,
                        // sizes:
                        //   "(max-width: 780px) 100vw, (max-width: 1200px) 100vw, 360px",
                        height: 900,
                        alt: product.name,
                      },
                      lensStyle: {
                        // height: "20px",
                        // borderRadius: "50%",
                        // width: "40px",
                      },
                    }}
                  /> */}
                </div>
              </div>
            </div>
            <div
              className="flex flex-col justify-between"
              style={{
                marginLeft: "41rem",
              }}
            >
              <h2 className="text-2xl font-semibold">{product.name}</h2>
              <br></br>
              <h2>Description:</h2>
              <p className="mr-10">{product.description}</p>
              <br></br>
              <br></br>
              <p className="text-5xl  font-extrabold">${product.price}</p>
              <br></br>
              <br></br>
              <div className="flex items-center justify-between w-[20rem]">
                <div className="one">
                  <h1 className="flex items-center mb-6">
                    <FaStore className="mr-2 text-white" /> Brand:{" "}
                    {product.brand}
                  </h1>
                  <h1 className="flex items-center mb-6 w-[20rem]">
                    <FaClock className="mr-2 text-white" /> Added:{" "}
                    {moment(product.createAt).fromNow()}
                  </h1>
                  <h1 className="flex items-center mb-6">
                    <FaStar className="mr-2 text-white" /> Reviews:{" "}
                    {product.numReviews}
                  </h1>
                </div>
                <div className="two">
                  <h1 className="flex items-center mb-6">
                    <FaStar className="mr-2 text-white" /> Ratings: {rating}
                  </h1>
                  <h1 className="flex items-center mb-6">
                    <FaShoppingCart className="mr-2 text-white" /> Quantity:{" "}
                    {product.quantity}
                  </h1>
                  <h1 className="flex items-center mb-6 w-[10rem]">
                    <FaBox className="mr-2 text-white" /> In Stock:{" "}
                    {product.countInStock}
                  </h1>
                </div>
              </div>

              <div className="flex justify-between flex-wrap">
                <Ratings
                  value={product.rating}
                  text={`${product.numReviews} reviews`}
                />

                {product.countInStock > 0 && (
                  <div className="pr-[3.8rem]">
                    <select
                      value={qty}
                      onChange={(e) => setQty(e.target.value)}
                      className="p-2 w-[6rem] rounded-lg text-black"
                    >
                      {[...Array(product.countInStock).keys()].map((x) => (
                        <option key={x + 1} value={x + 1}>
                          {x + 1}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div className=" flex mt-20">
                <button
                  onClick={addToCartHandler}
                  disabled={product.countInStock === 0}
                  className="bg-pink-600 h-[40px] text-white py-2 px-4 rounded-lg "
                >
                  Add To Cart
                </button>
                <div style={{}} className="">
                  <HeartIcon product={product} />
                </div>
              </div>
            </div>

            <div
              className="mt-[5rem] container flex flex-wrap items-start justify-between ml-[10rem]"
              style={{ marginLeft: "40rem" }}
            ></div>
            <ProductTabs
              loadingProductReview={loadingProductReview}
              userInfo={userInfo}
              submitHandler={submitHandler}
              rating={rating}
              setRating={setRating}
              comment={comment}
              setComment={setComment}
              product={product}
            />
            <br></br>
            <div className="flex flex-col pt-[100px] pr-[40px]">
              <td className="flex">
                <thead className="xl:w-[92rem] pl-[40rem] w-20 h-10 pl-2 pt-2 pd1 my-4">
                  <tr className="">Product Specification</tr>
                </thead>
              </td>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName2}
                </p>
                <p className="w-full h-full pt-[6px] pl-2 pd">
                  {product.description2}
                </p>
              </div>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName3}
                </p>
                <p className="w-full pl-2 pt-2 pd">{product.description3}</p>
              </div>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName4}
                </p>
                <p className="w-full pl-2 pt-2 pd">{product.description4}</p>
              </div>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName5}
                </p>
                <p className="pd w-full pl-2 pt-2 pd">{product.description5}</p>
              </div>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName6}
                </p>
                <p className="pd w-full pl-2 pt-2">{product.description6}</p>
              </div>
              <div className="flex">
                <p className="w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName7}
                </p>
                <p className="pd w-full pl-2 pt-2">{product.description7}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName8}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description8}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName9}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description9}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName10}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description10}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName11}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description11}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName12}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description12}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName13}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description13}</p>
              </div>
              <div className="flex">
                <p className=" w-60 h-full pt-[1rem] pl-[2rem] pd">
                  {product.pdName14}
                </p>
                <p className="pd   w-full pl-2 pt-2">{product.description14}</p>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default ProductDetails;
